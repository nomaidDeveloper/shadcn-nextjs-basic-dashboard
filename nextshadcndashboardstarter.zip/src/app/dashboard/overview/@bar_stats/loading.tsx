import { BarGraphSkeleton } from '@/features/overview/components/bar-graph-skeleton';

export default function Loading() {
  return <BarGraphSkeleton />;
}
